// Чистые функции коннектора (без зависимостей) — их проверяют тесты.

/** BigInt/Long/число/строка → строка; пустое → null. */
export function idString(value) {
  if (value === undefined || value === null) return null;
  const text = typeof value === 'object' && typeof value.toString === 'function'
    ? value.toString()
    : String(value);
  return text === '' || text === '0' ? null : text;
}

function toInt(value, fallback) {
  const n = Number(typeof value === 'bigint' ? value : value ?? NaN);
  return Number.isFinite(n) ? Math.trunc(n) : fallback;
}

/**
 * Подарок из tiktok-live-connector → плоский JSON для Dirronlive.
 * Поля читаются с запасными вариантами: в разных версиях библиотеки и
 * протокола TikTok они лежат в разных местах.
 */
export function normalizeGift(data) {
  const d = data ?? {};
  const details = d.giftDetails ?? d.gift ?? {};
  const user = d.user ?? {};
  const common = d.common ?? {};
  const giftType = toInt(details.giftType ?? d.giftType, 0);
  const repeatEndRaw = d.repeatEnd;
  return {
    type: 'gift',
    msgId: idString(common.msgId ?? d.msgId ?? d.logId),
    groupId: idString(d.groupId ?? details.groupId),
    giftId: idString(d.giftId ?? details.id) ?? 'unknown',
    giftName: String(
      details.giftName ?? d.extendedGiftInfo?.name ?? d.giftName ?? `Подарок ${d.giftId ?? ''}`,
    ).trim(),
    giftType,
    streakable: giftType === 1,
    repeatCount: Math.max(1, toInt(d.repeatCount, 1)),
    repeatEnd: repeatEndRaw === true || repeatEndRaw === 1 || repeatEndRaw === '1',
    userId: idString(user.userId ?? user.id ?? d.userId),
    uniqueId: user.uniqueId ? String(user.uniqueId) : null,
    nickname: user.nickname ? String(user.nickname) : null,
    createTime: idString(common.createTime ?? d.createTime),
  };
}

const NETWORK_CODES = [
  'ENOTFOUND', 'ECONNRESET', 'ECONNREFUSED', 'ETIMEDOUT', 'EAI_AGAIN',
  'ENETUNREACH', 'EHOSTUNREACH', 'ECONNABORTED', 'EPIPE', 'UND_ERR_CONNECT_TIMEOUT',
];

/**
 * Ошибка подключения → статус для Dirronlive:
 *   offline  — эфир не идёт (UserOfflineError);
 *   network  — нет сети / не отвечает сервер;
 *   service  — TikTok или сервер подписи Euler Stream отказали (лимиты и т. п.).
 */
export function classifyError(error) {
  const name = String(error?.name ?? error?.constructor?.name ?? 'Error');
  const message = String(error?.message ?? error ?? '');
  const code = String(error?.code ?? error?.cause?.code ?? '');
  const text = `${name} ${code} ${message}`;

  if (/UserOffline/i.test(text) || /isn't online|is not online|not live|offline/i.test(message)) {
    return { status: 'offline', kind: 'offline', message: 'Эфир не найден: аккаунт сейчас не в эфире.' };
  }
  if (/InvalidUniqueId/i.test(text) || /user.*not.*found|unique.?id/i.test(message)) {
    return { status: 'error', kind: 'service', message: 'TikTok не нашёл такой аккаунт. Проверьте ник.' };
  }
  if (/RateLimit/i.test(text) || /\b429\b/.test(text)) {
    return {
      status: 'error', kind: 'service',
      message: 'Сервер подписи Euler Stream ограничил частоту подключений. Подождите минуту или укажите свой бесплатный ключ Euler Stream.',
    };
  }
  if (NETWORK_CODES.some((c) => text.includes(c)) || /ConnectTimeout|network|fetch failed|socket hang up|timed? ?out/i.test(text)) {
    return { status: 'error', kind: 'network', message: `Ошибка сети: ${message || code}`.trim() };
  }
  return { status: 'error', kind: 'service', message: `Ошибка сервиса TikTok LIVE: ${message || name}` };
}

/** Разбор аргументов: --user ник [--key ключ] [--self-check]. */
export function parseArgs(argv) {
  const args = { user: null, key: null, selfCheck: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--self-check') args.selfCheck = true;
    else if (a === '--user') args.user = argv[++i] ?? null;
    else if (a === '--key') args.key = argv[++i] ?? null;
  }
  if (args.user) args.user = args.user.trim().replace(/^@/, '');
  if (args.key) args.key = args.key.trim() || null;
  return args;
}

/** JSON.stringify, который не падает на BigInt. */
export function toJsonLine(object) {
  return JSON.stringify(object, (_k, v) => (typeof v === 'bigint' ? v.toString() : v));
}
