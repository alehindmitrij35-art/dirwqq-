import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';

/// Подключается к каждому тесту автоматически.
///
/// По умолчанию упавший тест интерфейса сообщает только «Test failed. See
/// exception logs above.», а сам текст ошибки уходит в лог. Здесь текст
/// исключения и строки стека из проекта добавляются к описанию теста —
/// так причина видна прямо в сводке сборки на GitHub.
Future<void> testExecutable(FutureOr<void> Function() testMain) async {
  final original = reportTestException;
  reportTestException = (FlutterErrorDetails details, String testDescription) {
    final context = details.context?.toDescription() ?? '';
    final stack = (details.stack?.toString() ?? '')
        .split('\n')
        .where((line) => line.contains('dirronlive') || line.contains('_test.dart'))
        .take(8)
        .join('\n');
    original(
      details,
      '$testDescription\n--- $context\n${details.exceptionAsString()}\n$stack',
    );
  };
  await testMain();
}
