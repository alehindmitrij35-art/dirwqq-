import 'package:dirronlive/app.dart';
import 'package:dirronlive/bootstrap.dart';
import 'package:dirronlive/core/initial_data.dart';
import 'package:dirronlive/core/storage/json_store.dart';
import 'package:dirronlive/features/events/event_log.dart';
import 'package:dirronlive/features/minecraft/link_state.dart';
import 'package:dirronlive/features/minecraft/minecraft_link.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

/// Запускает приложение «как с диска» поверх [store] в окне [size].
Future<ProviderContainer> pumpDirronlive(
  WidgetTester tester,
  JsonStore store, {
  Size size = const Size(1920, 1080),
  List<Override> overrides = const [],
}) async {
  tester.view.physicalSize = size;
  tester.view.devicePixelRatio = 1.0;
  addTearDown(tester.view.reset);

  final data = await tester.runAsync(() => loadInitialData(store));
  final container = createAppContainer(data!, overrides: overrides);
  await tester.pumpWidget(
    UncontrolledProviderScope(
      container: container,
      child: const DirronliveApp(),
    ),
  );
  await tester.pumpAndSettle();
  return container;
}

/// Если во время шага было исключение интерфейса (например, переполнение),
/// тест падает с его полным текстом — так причина видна в сводке сборки.
void expectNoFlutterError(WidgetTester tester, String where) {
  final Object? error = tester.takeException();
  if (error == null) return;
  final text = error is FlutterError ? error.toStringDeep() : '$error';
  fail('Исключение интерфейса ($where): $text');
}

/// Виден ли [item] целиком внутри [viewport] (например, запись внутри ленты).
/// Не зависит от того, есть ли что-то в геометрическом центре строки.
bool isFullyVisibleIn(WidgetTester tester, Finder item, Finder viewport) {
  if (item.evaluate().isEmpty) return false;
  final rect = tester.getRect(item);
  final view = tester.getRect(viewport);
  return rect.top >= view.top - 0.5 &&
      rect.bottom <= view.bottom + 0.5 &&
      rect.left >= view.left - 0.5 &&
      rect.right <= view.right + 0.5;
}

/// «Закрывает программу»: дожидается записи на диск и уничтожает дерево.
Future<void> closeDirronlive(
  WidgetTester tester,
  ProviderContainer container,
) async {
  await tester.pump();
  expectNoFlutterError(tester, 'перед закрытием');
  await tester.runAsync(() => container.read(eventLogProvider.notifier).flush());
  await tester.pumpWidget(const SizedBox.shrink());
  expectNoFlutterError(tester, 'при закрытии окна');
  // Даём всплывающим сообщениям и подсветке доиграть, чтобы не осталось таймеров.
  await tester.pump(const Duration(seconds: 10));
  expectNoFlutterError(tester, 'после закрытия');
  container.dispose();
}

/// Нажимает вкладку верхней строки (`live`, `modes`, `overlays`, `history`)
/// или кнопку `settings`.
Future<void> openSection(WidgetTester tester, String sectionName) async {
  final item = find.byKey(Key('nav-$sectionName'));
  await tester.tap(item);
  await tester.pumpAndSettle();
  expectNoFlutterError(tester, 'вкладка $sectionName');
}

/// Подменённая связь с игрой: состояние задаётся тестом, без сокетов.
class FakeLinkController extends MinecraftLinkController {
  FakeLinkController(this.initial);

  final MinecraftLinkState initial;
  int starts = 0;
  int stops = 0;
  int retries = 0;

  @override
  MinecraftLinkState build() => initial;

  @override
  Future<void> start() async {
    starts++;
    state = const MinecraftLinkState(
        phase: LinkPhase.waitingForMod, port: 8765);
  }

  @override
  Future<void> stop() async {
    stops++;
    state = const MinecraftLinkState();
  }

  @override
  Future<void> retry() async {
    retries++;
  }

  void show(MinecraftLinkState next) => state = next;
}

Override fakeLink(MinecraftLinkState initial) =>
    minecraftLinkProvider.overrideWith(() => FakeLinkController(initial));
