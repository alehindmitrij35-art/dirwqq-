import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

/// «Поддельный мод»: подключается к Dirronlive по WebSocket и говорит тем же
/// протоколом, что и Dirronlive Bridge в Minecraft.
class FakeMod {
  FakeMod._(this.socket) {
    socket.listen(
      (data) => messages.add(
          (jsonDecode(data as String) as Map).cast<String, Object?>()),
      onDone: () => closed = true,
    );
  }

  static Future<FakeMod> connect(int port) async => FakeMod._(
      await WebSocket.connect('ws://127.0.0.1:$port/dirronlive'));

  final WebSocket socket;
  final List<Map<String, Object?>> messages = [];
  bool closed = false;

  List<Map<String, Object?>> get gifts =>
      messages.where((m) => m['type'] == 'gift').toList();

  void send(Map<String, Object?> message) => socket.add(jsonEncode(message));

  void hello({required bool worldReady}) => send({
        'type': 'hello',
        'protocol': 1,
        'modVersion': '1.0.0',
        'minecraftVersion': '1.21.1',
        'worldReady': worldReady,
      });

  void world(bool ready) => send({'type': 'world', 'worldReady': ready});

  void ack(String id) => send({'type': 'ack', 'id': id});

  Future<void> close() => socket.close();
}

/// Ждёт условия до 5 секунд.
Future<void> waitFor(bool Function() condition, {String? reason}) async {
  final stopwatch = Stopwatch()..start();
  while (!condition()) {
    if (stopwatch.elapsed > const Duration(seconds: 5)) {
      fail('Не дождались: ${reason ?? 'условие'}');
    }
    await Future<void>.delayed(const Duration(milliseconds: 10));
  }
}


