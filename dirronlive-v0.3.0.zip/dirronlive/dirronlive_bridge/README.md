# Dirronlive Bridge 1.0.0

Клиентский мод для Minecraft Java 1.21.1 (Fabric). Связывает игру с
программой Dirronlive: подарки из программы появляются над панелью быстрого
доступа в одиночном мире.

- Нужны: Minecraft 1.21.1, Fabric Loader 0.16+, Java 21.
- Fabric API не обязателен: нужные модули уже внутри jar.
- Установка: положите `DirronliveBridge-1.0.0.jar` в папку `mods`.
- Сборка: `gradlew.bat build` или `build-mod.bat`. Результат лежит в
  `build\libs\DirronliveBridge-1.0.0.jar`.

Мод подключается к `ws://127.0.0.1:8765/dirronlive` и переподключается
каждые 2 секунды. Порт можно поменять: `-Ddirronlive.port=…`.
Подробности — в README.md программы.
