package dev.dirronlive.bridge;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.net.URI;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.junit.jupiter.api.Test;

/** Мод против настоящего WebSocket-сервера: без Minecraft, с поддельной «игрой». */
class BridgeConnectionTest {

    /** «Игра»: один игровой поток, как у Minecraft, и список показанных подарков. */
    static final class FakeGame implements BridgeConnection.Game {
        final ExecutorService gameThread = Executors.newSingleThreadExecutor();
        final List<BridgeProtocol.Gift> shown = new CopyOnWriteArrayList<>();
        final List<String> threads = new CopyOnWriteArrayList<>();
        volatile boolean worldReady;
        volatile String gameThreadName;

        FakeGame() throws Exception {
            gameThreadName = gameThread.submit(() -> Thread.currentThread().getName()).get();
        }

        @Override
        public boolean isWorldReady() {
            return worldReady;
        }

        @Override
        public void runOnGameThread(Runnable task) {
            gameThread.execute(task);
        }

        @Override
        public boolean showGift(BridgeProtocol.Gift gift) {
            threads.add(Thread.currentThread().getName());
            if (!worldReady) return false;
            shown.add(gift);
            return true;
        }
    }

    static BridgeConnection connect(TestWebSocketServer server, FakeGame game) {
        BridgeConnection connection = new BridgeConnection(
                URI.create("ws://127.0.0.1:" + server.port() + "/dirronlive"),
                game, "1.0.0", "1.21.1", Duration.ofMillis(200), message -> {});
        connection.start();
        return connection;
    }

    static String gift(String id) {
        return MiniJson.object("type", "gift", "id", id,
                "viewerName", "Тестовый зритель", "giftName", "Роза", "count", 1);
    }

    @Test
    void helloWithVersionsAndWorldState() throws Exception {
        try (TestWebSocketServer server = new TestWebSocketServer()) {
            FakeGame game = new FakeGame();
            game.worldReady = false;
            BridgeConnection connection = connect(server, game);

            String hello = server.nextOfType("hello", 5000);
            assertNotNull(hello, "мод должен представиться");
            Map<String, Object> m = MiniJson.parseObject(hello);
            assertEquals("1.0.0", m.get("modVersion"));
            assertEquals("1.21.1", m.get("minecraftVersion"));
            assertEquals(Boolean.FALSE, m.get("worldReady"));
            assertEquals(1L, m.get("protocol"));

            connection.onWorldState(true); // вошёл в мир
            assertEquals(Boolean.TRUE,
                    MiniJson.parseObject(server.nextOfType("world", 3000)).get("worldReady"));
            connection.onWorldState(true); // тот же статус — не дублируется
            connection.onWorldState(false); // вышел в меню
            assertEquals(Boolean.FALSE,
                    MiniJson.parseObject(server.nextOfType("world", 3000)).get("worldReady"));
            connection.stop();
        }
    }

    @Test
    void giftIsShownOnGameThreadThenAcknowledged() throws Exception {
        try (TestWebSocketServer server = new TestWebSocketServer()) {
            FakeGame game = new FakeGame();
            game.worldReady = true;
            BridgeConnection connection = connect(server, game);
            assertNotNull(server.nextOfType("hello", 5000));

            server.send(gift("id-1"));
            String ack = server.nextOfType("ack", 3000);
            assertNotNull(ack, "подтверждение после показа");
            assertEquals("id-1", MiniJson.parseObject(ack).get("id"));
            assertEquals(1, game.shown.size());
            assertEquals("Dirronlive • Тестовый зритель отправил «Роза» ×1", game.shown.get(0).overlayText());
            assertEquals(List.of(game.gameThreadName), game.threads, "показ — только в игровом потоке");
            connection.stop();
        }
    }

    @Test
    void duplicateIdIsAcknowledgedAgainButShownOnce() throws Exception {
        try (TestWebSocketServer server = new TestWebSocketServer()) {
            FakeGame game = new FakeGame();
            game.worldReady = true;
            BridgeConnection connection = connect(server, game);
            assertNotNull(server.nextOfType("hello", 5000));

            server.send(gift("same"));
            server.send(gift("same"));
            assertEquals("same", MiniJson.parseObject(server.nextOfType("ack", 3000)).get("id"));
            assertEquals("same", MiniJson.parseObject(server.nextOfType("ack", 3000)).get("id"));
            assertEquals(1, game.shown.size());
            connection.stop();
        }
    }

    @Test
    void threeQuickGiftsGetThreeAcks() throws Exception {
        try (TestWebSocketServer server = new TestWebSocketServer()) {
            FakeGame game = new FakeGame();
            game.worldReady = true;
            BridgeConnection connection = connect(server, game);
            assertNotNull(server.nextOfType("hello", 5000));

            server.send(gift("a"));
            server.send(gift("b"));
            server.send(gift("c"));
            List<Object> acks = new CopyOnWriteArrayList<>();
            for (int i = 0; i < 3; i++) {
                acks.add(MiniJson.parseObject(server.nextOfType("ack", 3000)).get("id"));
            }
            assertEquals(List.of("a", "b", "c"), acks);
            assertEquals(3, game.shown.size());
            connection.stop();
        }
    }

    @Test
    void comboStepsAreShownImmediatelyEachWithOwnAck() throws Exception {
        try (TestWebSocketServer server = new TestWebSocketServer()) {
            FakeGame game = new FakeGame();
            game.worldReady = true;
            BridgeConnection connection = connect(server, game);
            assertNotNull(server.nextOfType("hello", 5000));

            for (int total = 1; total <= 5; total++) {
                server.send(MiniJson.object("type", "gift", "id", "combo:" + total,
                        "viewerName", "Тестовый зритель", "giftName", "Роза",
                        "count", 1, "combo", true, "comboTotal", total));
                assertEquals("combo:" + total,
                        MiniJson.parseObject(server.nextOfType("ack", 3000)).get("id"));
            }
            assertEquals(5, game.shown.size());
            assertEquals("Dirronlive • Тестовый зритель отправил «Роза» ×5", game.shown.get(4).overlayText());
            connection.stop();
        }
    }

    @Test
    void noAckWhenWorldIsNotReady() throws Exception {
        try (TestWebSocketServer server = new TestWebSocketServer()) {
            FakeGame game = new FakeGame();
            game.worldReady = false;
            BridgeConnection connection = connect(server, game);
            assertNotNull(server.nextOfType("hello", 5000));

            server.send(gift("menu"));
            assertNull(server.nextOfType("ack", 700), "в меню подарок не подтверждается");
            assertTrue(game.shown.isEmpty());
            connection.stop();
        }
    }

    @Test
    void reconnectsAfterDropAndWhenServerStartsLater() throws Exception {
        int port;
        try (TestWebSocketServer probe = new TestWebSocketServer()) {
            port = probe.port();
        }
        FakeGame game = new FakeGame();
        game.worldReady = true;
        // Игра запущена раньше программы: сервера пока нет.
        BridgeConnection connection = new BridgeConnection(
                URI.create("ws://127.0.0.1:" + port + "/dirronlive"),
                game, "1.0.0", "1.21.1", Duration.ofMillis(200), message -> {});
        connection.start();
        Thread.sleep(600);
        assertFalse(connection.isConnected());

        try (TestWebSocketServer server = new TestWebSocketServer(port)) {
            assertNotNull(server.nextOfType("hello", 5000), "подключился, когда программа появилась");
            assertEquals(1, server.connections());

            server.dropClient(); // программу закрыли / связь оборвалась
            assertTrue(server.awaitClient(5000)); // первое подключение
            assertTrue(server.awaitClient(5000), "переподключился после разрыва");
            assertNotNull(server.nextOfType("hello", 5000));
            assertEquals(2, server.connections());

            server.send(gift("after-reconnect"));
            assertNotNull(server.nextOfType("ack", 3000));
        } finally {
            connection.stop();
        }
    }
}
