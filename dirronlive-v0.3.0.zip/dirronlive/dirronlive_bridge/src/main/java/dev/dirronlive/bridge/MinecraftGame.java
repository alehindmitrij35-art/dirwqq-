package dev.dirronlive.bridge;

import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Всё, что мод делает внутри Minecraft. */
final class MinecraftGame implements BridgeConnection.Game {
    private volatile boolean worldReady;

    /**
     * Мир готов: запущен одиночный мир (встроенный сервер) и есть локальный
     * игрок. Вызывается каждый тик в игровом потоке.
     */
    boolean updateWorldReady(MinecraftClient client) {
        boolean ready = client.isIntegratedServerRunning()
                && client.getServer() != null
                && client.world != null
                && client.player != null;
        worldReady = ready;
        return ready;
    }

    @Override
    public boolean isWorldReady() {
        return worldReady;
    }

    @Override
    public void runOnGameThread(Runnable task) {
        MinecraftClient.getInstance().execute(task);
    }

    @Override
    public boolean showGift(BridgeProtocol.Gift gift) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!updateWorldReady(client) || client.inGameHud == null) return false;

        // «Dirronlive • Alex отправил «Роза» ×5» над панелью быстрого доступа.
        // Серия подарков приходит сюда один раз — с итоговым количеством.
        MutableText text = Text.literal("Dirronlive").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD)
                .append(Text.literal(" • ").formatted(Formatting.GRAY))
                .append(Text.literal(gift.viewerName()).formatted(Formatting.WHITE, Formatting.BOLD))
                .append(Text.literal(" отправил ").formatted(Formatting.GRAY))
                .append(Text.literal(gift.giftText()).formatted(Formatting.GOLD));
        client.inGameHud.setOverlayMessage(text, false);
        if (client.player != null) {
            client.player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.6f, 1.4f);
        }
        return true;
    }
}
