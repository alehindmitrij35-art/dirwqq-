package dev.dirronlive.bridge;

import java.util.Map;

/**
 * Протокол обмена с программой Dirronlive (JSON по WebSocket).
 *
 * <pre>
 * Мод → программа:
 *   {"type":"hello","protocol":1,"modVersion":"1.0.0","minecraftVersion":"1.21.1","worldReady":false}
 *   {"type":"world","worldReady":true}
 *   {"type":"ack","id":"…"}
 * Программа → мод:
 *   {"type":"welcome","app":"Dirronlive","protocol":1}
 *   {"type":"gift","id":"…","viewerName":"…","giftName":"Роза","count":1}
 *   {"type":"gift","id":"…","viewerName":"…","giftName":"Роза","count":1,"combo":true,"comboTotal":15}
 * </pre>
 *
 * <p>{@code count} — сколько подарков применить сейчас (для шага комбо —
 * прирост), {@code comboTotal} — сколько всего в серии комбо.
 */
public final class BridgeProtocol {
    public static final int VERSION = 1;
    public static final int DEFAULT_PORT = 8765;

    private BridgeProtocol() {}

    /**
     * Подарок, пришедший из программы. {@code comboTotal} = 0 для одиночного
     * подарка, иначе — сколько всего подарков в серии комбо.
     */
    public record Gift(String id, String viewerName, String giftName, int count, int comboTotal) {
        public boolean isCombo() {
            return comboTotal > 0;
        }

        /** Сколько подарков показать: для серии — итог серии. */
        public int total() {
            return isCombo() ? comboTotal : count;
        }

        /** «Роза» ×5 */
        public String giftText() {
            return "«" + giftName + "» ×" + total();
        }

        /** Текст над панелью быстрого доступа: «Dirronlive • Alex отправил «Роза» ×5». */
        public String overlayText() {
            return "Dirronlive • " + viewerName + " отправил " + giftText();
        }
    }

    public static String hello(String modVersion, String minecraftVersion, boolean worldReady) {
        return MiniJson.object(
                "type", "hello",
                "protocol", VERSION,
                "modVersion", modVersion,
                "minecraftVersion", minecraftVersion,
                "worldReady", worldReady);
    }

    public static String world(boolean worldReady) {
        return MiniJson.object("type", "world", "worldReady", worldReady);
    }

    public static String ack(String id) {
        return MiniJson.object("type", "ack", "id", id);
    }

    /** Возвращает подарок или {@code null}, если сообщение не подарок или повреждено. */
    public static Gift parseGift(String text) {
        Map<String, Object> m;
        try {
            m = MiniJson.parseObject(text);
        } catch (IllegalArgumentException e) {
            return null;
        }
        if (!"gift".equals(m.get("type"))) return null;
        if (!(m.get("id") instanceof String id) || id.isBlank() || id.length() > 128) return null;
        int count = m.get("count") instanceof Long n && n >= 1 && n <= 1_000_000 ? n.intValue() : 1;
        int comboTotal = m.get("comboTotal") instanceof Long t && t >= 1 && t <= 1_000_000 ? t.intValue() : 0;
        if (comboTotal > 0 && comboTotal < count) comboTotal = count;
        return new Gift(
                id,
                clean(m.get("viewerName"), "Зритель"),
                clean(m.get("giftName"), "Подарок"),
                count,
                comboTotal);
    }

    /** Убирает управляющие символы и коды форматирования Minecraft (§), ограничивает длину. */
    static String clean(Object value, String fallback) {
        if (!(value instanceof String s)) return fallback;
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < s.length() && out.length() < 48; i++) {
            char c = s.charAt(i);
            if (c == '§' || Character.isISOControl(c)) continue;
            out.append(c);
        }
        String result = out.toString().strip();
        return result.isEmpty() ? fallback : result;
    }
}
