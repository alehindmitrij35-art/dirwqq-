package dev.dirronlive.bridge;

import java.time.Duration;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Точка входа мода Dirronlive Bridge (только клиент). */
public final class DirronliveBridgeClient implements ClientModInitializer {
    public static final String MOD_ID = "dirronlive_bridge";
    private static final Logger LOG = LoggerFactory.getLogger("Dirronlive Bridge");

    private BridgeConnection connection;

    @Override
    public void onInitializeClient() {
        MinecraftGame game = new MinecraftGame();
        connection = new BridgeConnection(
                BridgeConnection.defaultUri(),
                game,
                versionOf(MOD_ID),
                versionOf("minecraft"),
                Duration.ofSeconds(2),
                LOG::info);

        ClientTickEvents.END_CLIENT_TICK.register(client ->
                connection.onWorldState(game.updateWorldReady(client)));
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> connection.stop());

        connection.start();
        LOG.info("Dirronlive Bridge запущен, адрес программы: {}", BridgeConnection.defaultUri());
    }

    private static String versionOf(String modId) {
        return FabricLoader.getInstance().getModContainer(modId)
                .map(container -> container.getMetadata().getVersion().getFriendlyString())
                .orElse("?");
    }
}
