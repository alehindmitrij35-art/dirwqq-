package dev.dirronlive.bridge;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * WebSocket-клиент мода. Подключается к Dirronlive на 127.0.0.1 и, пока
 * мод работает, сам переподключается после разрыва — порядок запуска игры
 * и программы не важен.
 *
 * <p>Сетевая часть работает в своих потоках; всё, что касается игрока,
 * передаётся в игровой поток через {@link Game#runOnGameThread}.
 * Подтверждение ({@code ack}) отправляется только после того, как подарок
 * показан. Повторный ID подтверждается снова, но не показывается.
 */
public final class BridgeConnection {

    /** То, что мод умеет делать в игре. Реализация для Minecraft — {@code MinecraftGame}. */
    public interface Game {
        /** Можно вызывать из любого потока. */
        boolean isWorldReady();

        void runOnGameThread(Runnable task);

        /** Вызывается в игровом потоке. Возвращает {@code true}, если подарок показан. */
        boolean showGift(BridgeProtocol.Gift gift);
    }

    private final URI uri;
    private final Game game;
    private final String modVersion;
    private final String minecraftVersion;
    private final long reconnectMillis;
    private final Consumer<String> log;
    private final HttpClient http;
    private final ScheduledExecutorService scheduler;
    private final GiftDeduplicator shown = new GiftDeduplicator(2000);

    private volatile boolean running;
    private volatile boolean connecting;
    private volatile WebSocket socket;
    private volatile boolean reportedWorldReady;
    private volatile boolean failureLogged;
    private CompletableFuture<Void> sendChain = CompletableFuture.completedFuture(null);

    public BridgeConnection(URI uri, Game game, String modVersion, String minecraftVersion,
                            Duration reconnectDelay, Consumer<String> log) {
        this.uri = uri;
        this.game = game;
        this.modVersion = modVersion;
        this.minecraftVersion = minecraftVersion;
        this.reconnectMillis = Math.max(100, reconnectDelay.toMillis());
        this.log = log;
        this.http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(2)).build();
        this.scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "Dirronlive Bridge");
            t.setDaemon(true);
            return t;
        });
    }

    public static URI defaultUri() {
        int port = Integer.getInteger("dirronlive.port", BridgeProtocol.DEFAULT_PORT);
        return URI.create("ws://127.0.0.1:" + port + "/dirronlive");
    }

    public void start() {
        if (running) return;
        running = true;
        scheduler.scheduleWithFixedDelay(this::ensureConnected, 0, reconnectMillis, TimeUnit.MILLISECONDS);
    }

    public void stop() {
        running = false;
        WebSocket ws = socket;
        socket = null;
        if (ws != null) {
            try {
                ws.sendClose(WebSocket.NORMAL_CLOSURE, "Minecraft закрывается");
            } catch (RuntimeException ignored) {
                // Соединение уже закрыто.
            }
            ws.abort();
        }
        scheduler.shutdownNow();
    }

    public boolean isConnected() {
        return socket != null;
    }

    /** Вызывается каждый игровой тик: сообщает программе о входе в мир и выходе из него. */
    public void onWorldState(boolean ready) {
        if (ready == reportedWorldReady) return;
        reportedWorldReady = ready;
        send(BridgeProtocol.world(ready));
    }

    private void ensureConnected() {
        if (!running || socket != null || connecting) return;
        connecting = true;
        try {
            http.newWebSocketBuilder()
                    .connectTimeout(Duration.ofSeconds(2))
                    .buildAsync(uri, new Listener())
                    .whenComplete((ws, error) -> {
                        connecting = false;
                        if (error != null) {
                            if (!failureLogged) {
                                failureLogged = true;
                                log.accept("Dirronlive не отвечает на " + uri
                                        + " — жду, пока в программе включат связь с игрой.");
                            }
                        } else if (!running) {
                            ws.abort();
                        }
                    });
        } catch (RuntimeException e) {
            connecting = false;
        }
    }

    private synchronized void send(String text) {
        WebSocket ws = socket;
        if (ws == null) return;
        // Java WebSocket не допускает параллельных отправок — ставим в очередь.
        sendChain = sendChain
                .exceptionally(error -> null)
                .thenCompose(ignored -> ws.sendText(text, true))
                .thenAccept(ignored -> {});
    }

    private void handleText(String text) {
        BridgeProtocol.Gift gift = BridgeProtocol.parseGift(text);
        if (gift == null) return;
        game.runOnGameThread(() -> deliver(gift));
    }

    /** Игровой поток. */
    private void deliver(BridgeProtocol.Gift gift) {
        if (shown.contains(gift.id())) {
            send(BridgeProtocol.ack(gift.id()));
            return;
        }
        if (game.showGift(gift)) {
            shown.remember(gift.id());
            send(BridgeProtocol.ack(gift.id()));
        }
        // Мир не готов — подарок не показан и не подтверждён:
        // программа отметит его «Доставка не подтверждена».
    }

    private void dropped(WebSocket ws, String why) {
        synchronized (this) {
            if (socket != ws) return;
            socket = null;
        }
        failureLogged = false;
        if (running) log.accept("Связь с Dirronlive потеряна (" + why + "), переподключаюсь…");
    }

    private final class Listener implements WebSocket.Listener {
        private final StringBuilder buffer = new StringBuilder();

        @Override
        public void onOpen(WebSocket ws) {
            synchronized (BridgeConnection.this) {
                socket = ws;
                sendChain = CompletableFuture.completedFuture(null);
            }
            failureLogged = false;
            boolean ready = game.isWorldReady();
            reportedWorldReady = ready;
            send(BridgeProtocol.hello(modVersion, minecraftVersion, ready));
            log.accept("Подключено к Dirronlive (" + uri + ").");
            ws.request(1);
        }

        @Override
        public CompletionStage<?> onText(WebSocket ws, CharSequence data, boolean last) {
            buffer.append(data);
            if (last) {
                String text = buffer.toString();
                buffer.setLength(0);
                handleText(text);
            }
            ws.request(1);
            return null;
        }

        @Override
        public CompletionStage<?> onClose(WebSocket ws, int statusCode, String reason) {
            dropped(ws, "код " + statusCode);
            return null;
        }

        @Override
        public void onError(WebSocket ws, Throwable error) {
            dropped(ws, String.valueOf(error.getMessage()));
        }
    }
}
