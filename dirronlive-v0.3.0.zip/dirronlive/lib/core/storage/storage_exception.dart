/// Ошибка чтения или записи данных на диск.
/// [message] уже написано по-русски и подходит для показа пользователю.
class StorageException implements Exception {
  const StorageException(this.message);

  final String message;

  @override
  String toString() => message;
}
