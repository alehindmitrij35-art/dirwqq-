import '../features/events/event_history_repository.dart';
import '../features/settings/app_settings.dart';
import '../features/settings/settings_repository.dart';
import 'events/gift_event.dart';
import 'storage/json_store.dart';

/// Всё, что читается с диска до показа первого окна.
class InitialData {
  const InitialData({
    required this.store,
    required this.history,
    required this.settings,
    this.warnings = const [],
  });

  final JsonStore store;

  /// Сохранённые события, новые сверху.
  final List<GiftEvent> history;
  final AppSettings settings;

  /// Сообщения для пользователя о проблемах при загрузке.
  final List<String> warnings;
}

Future<InitialData> loadInitialData(JsonStore store) async {
  final history = await EventHistoryRepository(store).load();
  final settings = await SettingsRepository(store).load();
  return InitialData(
    store: store,
    history: history.events,
    settings: settings.settings,
    warnings: [...history.warnings, ...settings.warnings],
  );
}
