import 'dart:convert';

import '../../core/events/gift_event.dart';

/// Протокол обмена с модом Dirronlive Bridge (JSON-сообщения по WebSocket).
///
/// Мод → программа:
///   {"type":"hello","protocol":1,"modVersion":"1.0.0",
///    "minecraftVersion":"1.21.1","worldReady":false}
///   {"type":"world","worldReady":true}
///   {"type":"ack","id":"…"}
///
/// Программа → мод:
///   {"type":"welcome","app":"Dirronlive","protocol":1}
///   {"type":"gift","id":"…","viewerName":"…","giftName":"Роза","count":1}
abstract final class LinkProtocol {
  static const version = 1;
  static const defaultPort = 8765;

  static String welcome() =>
      jsonEncode({'type': 'welcome', 'app': 'Dirronlive', 'protocol': version});

  /// Сообщение моду. [deliveryId] — уникальный ID этой отправки (по нему
  /// приходит подтверждение), [units] — сколько подарков применить сейчас.
  static String gift({
    required String deliveryId,
    required GiftEvent record,
    required int units,
    int? comboTotal,
  }) =>
      jsonEncode({
        'type': 'gift',
        'id': deliveryId,
        'viewerName': record.viewerName,
        'giftName': record.giftName,
        'count': units,
        if (comboTotal != null) 'combo': true,
        if (comboTotal != null) 'comboTotal': comboTotal,
      });

  /// Разбирает сообщение мода. Возвращает `null` для мусора.
  static ModMessage? parse(Object? data) {
    if (data is! String) return null;
    Object? decoded;
    try {
      decoded = jsonDecode(data);
    } on FormatException {
      return null;
    }
    if (decoded is! Map) return null;
    switch (decoded['type']) {
      case 'hello':
        return ModHello(
          modVersion: _string(decoded['modVersion']),
          minecraftVersion: _string(decoded['minecraftVersion']),
          worldReady: decoded['worldReady'] == true,
        );
      case 'world':
        return ModWorld(worldReady: decoded['worldReady'] == true);
      case 'ack':
        final id = decoded['id'];
        if (id is String && id.isNotEmpty) return ModAck(id);
        return null;
      default:
        return null;
    }
  }

  static String? _string(Object? value) =>
      value is String && value.isNotEmpty ? value : null;
}

sealed class ModMessage {
  const ModMessage();
}

class ModHello extends ModMessage {
  const ModHello({this.modVersion, this.minecraftVersion, required this.worldReady});

  final String? modVersion;
  final String? minecraftVersion;
  final bool worldReady;
}

class ModWorld extends ModMessage {
  const ModWorld({required this.worldReady});

  final bool worldReady;
}

class ModAck extends ModMessage {
  const ModAck(this.id);

  final String id;
}
