/// Фактическое состояние связи с модом Dirronlive Bridge.
enum LinkPhase {
  off('Связь выключена'),
  starting('Запуск связи…'),
  waitingForMod('Ожидание мода'),
  modConnected('Мод подключён • открой одиночный мир'),
  worldReady('Мир готов'),
  error('Ошибка связи');

  const LinkPhase(this.label);

  final String label;
}

class MinecraftLinkState {
  const MinecraftLinkState({
    this.phase = LinkPhase.off,
    this.port,
    this.errorTitle,
    this.errorMessage,
    this.modVersion,
    this.minecraftVersion,
  });

  final LinkPhase phase;

  /// Порт, на котором работает (или пытался запуститься) сервер.
  final int? port;

  /// Короткий заголовок ошибки, например «Порт 8765 занят».
  final String? errorTitle;

  /// Понятное объяснение ошибки и что делать.
  final String? errorMessage;

  /// Версии, которые сообщил мод при подключении.
  final String? modVersion;
  final String? minecraftVersion;

  /// Связь включена пользователем (сервер работает или пытается).
  bool get enabled => phase != LinkPhase.off;

  bool get modConnected =>
      phase == LinkPhase.modConnected || phase == LinkPhase.worldReady;

  bool get worldReady => phase == LinkPhase.worldReady;

  /// Текст статуса — одинаковый на экране «Эфир» и в настройках.
  String get label =>
      phase == LinkPhase.error ? (errorTitle ?? phase.label) : phase.label;

  MinecraftLinkState copyWith({
    LinkPhase? phase,
    String? modVersion,
    String? minecraftVersion,
  }) =>
      MinecraftLinkState(
        phase: phase ?? this.phase,
        port: port,
        errorTitle: errorTitle,
        errorMessage: errorMessage,
        modVersion: modVersion ?? this.modVersion,
        minecraftVersion: minecraftVersion ?? this.minecraftVersion,
      );
}
