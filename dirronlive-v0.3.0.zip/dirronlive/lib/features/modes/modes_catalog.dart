/// Этап готовности игрового режима.
enum ModeStage {
  planned('В планах'),
  inDevelopment('В разработке'),
  ready('Готов');

  const ModeStage(this.label);

  final String label;
}

/// Описание игрового режима. Новые режимы добавляются по одному
/// в [gameModes]; запуск режима появится на следующих этапах.
class GameModeInfo {
  const GameModeInfo({
    required this.id,
    required this.title,
    required this.description,
    required this.stage,
  });

  final String id;
  final String title;
  final String description;
  final ModeStage stage;
}

const gameModes = <GameModeInfo>[
  GameModeInfo(
    id: 'dirron_parkour_100',
    title: 'Dirron Parkour: 100 Levels',
    description: 'Сто паркур-уровней с растущей сложностью. Подарки зрителей '
        'помогают пройти уровень или, наоборот, мешают.',
    stage: ModeStage.planned,
  ),
  GameModeInfo(
    id: 'maze_escape',
    title: 'Побег из лабиринта',
    description: 'Нужно выбраться из лабиринта, а зрители подарками открывают '
        'проходы, ставят ловушки и перестраивают стены.',
    stage: ModeStage.planned,
  ),
  GameModeInfo(
    id: 'evolution_chaos',
    title: 'Evolution Chaos',
    description: 'Мир постепенно мутирует: подарки запускают эволюцию мобов, '
        'блоков и правил игры.',
    stage: ModeStage.planned,
  ),
];
