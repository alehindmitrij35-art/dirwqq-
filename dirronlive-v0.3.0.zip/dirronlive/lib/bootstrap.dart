import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/initial_data.dart';
import 'core/providers.dart';
import 'features/events/event_log.dart';
import 'features/minecraft/gift_delivery.dart';
import 'features/minecraft/minecraft_link.dart';

/// Создаёт контейнер провайдеров приложения.
///
/// Порядок важен: сначала журнал (он первым получает каждое событие из шины),
/// затем доставка в игру (она меняет статус уже записанного события).
/// Если в настройках связь с игрой была включена, сервер поднимается сразу.
ProviderContainer createAppContainer(
  InitialData data, {
  List<Override> overrides = const [],
  bool autoStartMinecraftLink = true,
}) {
  final container = ProviderContainer(
    overrides: [
      initialDataProvider.overrideWithValue(data),
      ...overrides,
    ],
  );
  container.read(eventLogProvider);
  container.read(giftDeliveryProvider);
  if (autoStartMinecraftLink && data.settings.minecraftLinkEnabled) {
    unawaited(container.read(minecraftLinkProvider.notifier).start());
  }
  return container;
}
