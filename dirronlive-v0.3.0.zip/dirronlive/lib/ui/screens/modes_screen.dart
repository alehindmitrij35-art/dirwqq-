import 'package:flutter/material.dart';

import '../../features/modes/modes_catalog.dart';
import '../theme/app_colors.dart';
import '../widgets/common.dart';

/// Каталог мини-игр в виде сетки карточек.
class ModesScreen extends StatelessWidget {
  const ModesScreen({super.key});

  static IconData _iconFor(String id) => switch (id) {
        'dirron_parkour_100' => Icons.directions_run_rounded,
        'maze_escape' => Icons.grid_4x4_rounded,
        'evolution_chaos' => Icons.auto_awesome_rounded,
        _ => Icons.sports_esports_rounded,
      };

  static Color _stageColor(ModeStage stage) => switch (stage) {
        ModeStage.planned => AppColors.accentAlt,
        ModeStage.inDevelopment => AppColors.warning,
        ModeStage.ready => AppColors.success,
      };

  @override
  Widget build(BuildContext context) {
    return SectionPage(
      title: 'Режимы',
      subtitle: 'Мини-игры, которыми будут управлять подарки зрителей',
      children: [
        LayoutBuilder(
          builder: (context, constraints) {
            const spacing = 16.0;
            final width = constraints.maxWidth;
            final columns = width >= 900 ? 3 : (width >= 560 ? 2 : 1);
            final cardWidth =
                ((width - spacing * (columns - 1)) / columns).floorToDouble();
            return Wrap(
              spacing: spacing,
              runSpacing: spacing,
              children: [
                for (final mode in gameModes)
                  SizedBox(
                    width: cardWidth,
                    child: _ModeCard(
                      key: ValueKey('mode-${mode.id}'),
                      mode: mode,
                      icon: _iconFor(mode.id),
                      stageColor: _stageColor(mode.stage),
                    ),
                  ),
              ],
            );
          },
        ),
      ],
    );
  }
}

class _ModeCard extends StatelessWidget {
  const _ModeCard({
    super.key,
    required this.mode,
    required this.icon,
    required this.stageColor,
  });

  final GameModeInfo mode;
  final IconData icon;
  final Color stageColor;

  @override
  Widget build(BuildContext context) {
    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              IconBadge(icon: icon, size: 48),
              const Spacer(),
              TagChip(label: mode.stage.label, color: stageColor),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            mode.title,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: AppColors.text,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            mode.description,
            style: const TextStyle(
              fontSize: 14,
              height: 1.4,
              color: AppColors.textMuted,
            ),
          ),
        ],
      ),
    );
  }
}
