import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app.dart';
import 'bootstrap.dart';
import 'core/initial_data.dart';
import 'core/storage/app_paths.dart';
import 'core/storage/json_file_store.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // %APPDATA%\Dirronlive — данные текущего пользователя Windows.
  final store = FileJsonStore(resolveDataDirectory());
  final data = await loadInitialData(store);
  final container = createAppContainer(data);

  runApp(
    UncontrolledProviderScope(
      container: container,
      child: const DirronliveApp(),
    ),
  );
}
